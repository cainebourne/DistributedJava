function buttonClick(){
    alert("something...\nYou pressed the button");
}